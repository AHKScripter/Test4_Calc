#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

double sum(double a, double b);
double mynus(double a, double b);
double multiply(double a, double b);
double share(double a, double b);
double elevate(double a, double b);


