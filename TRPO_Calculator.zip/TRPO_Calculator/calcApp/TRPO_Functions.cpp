#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <cmath>
#include <clocale>
#include <stdlib.h>
#include <string.h>


double sum(double a, double b) {
    double r;
    r = a + b;
    return r;
}

double mynus(double a, double b) {
    double r;
    r = a - b;
    return r;
}

double multiply(double a, double b) {
    double r;
    r = a * b;
    return r;
}
double share(double a, double b) {
    double r;
    r = a / b;
    return r;
}

double elevate(double a, double b) {
    double r;
    r = pow(a, b);
    return r;
}


